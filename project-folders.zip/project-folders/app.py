from flask import Flask, request, render_template, send_from_directory
import requests
import cv2
from object_detector import *  # Pastikan library ini tersedia
import numpy as np
import os

app = Flask(__name__)

# API Key Remove.bg (Ganti dengan API Key yang valid)
api_key = '9nBeapFXZAE8Ah4juMgxKav5'

UPLOAD_FOLDER = 'static/uploads'
RESULT_FOLDER = 'static/results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

def remove_background(file_path):
    """Menghapus latar belakang gambar menggunakan Remove.bg API"""
    api_url = 'https://api.remove.bg/v1.0/removebg'
    response = requests.post(api_url, headers={'X-Api-Key': api_key}, files={'image_file': open(file_path, 'rb')})
    
    if response.status_code == 200:
        output_path = os.path.join(RESULT_FOLDER, 'output_image.png')
        with open(output_path, 'wb') as output_image:
            output_image.write(response.content)
        return output_path
    else:
        return None

def proses_gambar(file_path):
    """Mendeteksi objek dan mengukur dimensinya menggunakan OpenCV setelah menghapus latar belakang"""
    file_path = remove_background(file_path)
    if not file_path:
        return None, None
    
    parameters = cv2.aruco.DetectorParameters()
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_50)
    detector = HomogeneousBgDetector()
    img = cv2.imread(file_path)
    
    # Deteksi Aruco Marker
    corners, _, _ = cv2.aruco.detectMarkers(img, aruco_dict, parameters=parameters)
    if not corners:
        return None, None
    
    int_corners = np.int0(corners)
    cv2.polylines(img, int_corners, True, (0, 255, 0), 5)
    aruco_perimeter = cv2.arcLength(corners[0], True)
    pixel_cm_ratio = aruco_perimeter / 15
    
    contours = detector.detect_objects(img)
    keterangan = "Tidak ada objek terdeteksi."

    for cnt in contours:
        rect = cv2.minAreaRect(cnt)
        (x, y), (w, h), angle = rect
        object_width = w / pixel_cm_ratio
        object_height = h / pixel_cm_ratio
        
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        
        cv2.circle(img, (int(x), int(y)), 5, (0, 0, 255), -1)
        cv2.polylines(img, [box], True, (255, 0, 0), 2)
        cv2.putText(img, f"Width {round(object_width, 1)} cm", (int(x - 150), int(y - 70)),
                    cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), 2)
        cv2.putText(img, f"Height {round(object_height, 1)} cm", (int(x - 150), int(y - 100)),
                    cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), 2)

        keterangan = f"Objek terdeteksi: Lebar {round(object_width, 1)} cm, Tinggi {round(object_height, 1)} cm"

    output_path = os.path.join(RESULT_FOLDER, 'processed_image.png')
    cv2.imwrite(output_path, img)
    return output_path, keterangan

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'No file uploaded', 400
        file = request.files['file']
        if file.filename == '':
            return 'No selected file', 400
        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)
        
        processed_image, keterangan = proses_gambar(file_path)
        if not processed_image:
            return 'Processing failed', 500
        
        return render_template('index.html', uploaded_file=file.filename, processed_file='processed_image.png', keterangan=keterangan)

    return render_template('index.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/results/<filename>')
def result_file(filename):
    return send_from_directory(RESULT_FOLDER, filename)

if __name__ == '__main__':
    app.run(debug=True)
