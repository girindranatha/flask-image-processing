import tkinter as tk
from tkinter import filedialog
import requests
from PIL import Image, ImageTk
import cv2
from object_detector import *  # Pastikan library ini tersedia
import numpy as np
from matplotlib import pyplot as plt

# API Key Remove.bg (Ganti dengan API Key yang valid)
api_key = '9nBeapFXZAE8Ah4juMgxKav5'

def remove_background(file_path):
    """Menghapus latar belakang gambar menggunakan Remove.bg API"""
    api_url = 'https://api.remove.bg/v1.0/removebg'
    response = requests.post(api_url, headers={'X-Api-Key': api_key}, files={'image_file': open(file_path, 'rb')})
    
    if response.status_code == 200:
        output_path = 'output_image.png'
        with open(output_path, 'wb') as output_image:
            output_image.write(response.content)
        result_label.config(text='Background removed and saved as output_image.png')
        tampilkan_gambar(output_path)
        return output_path
    else:
        result_label.config(text=f'Error: {response.status_code}')
        return None

def proses_gambar(file_path):
    """Mendeteksi objek dan mengukur dimensinya menggunakan OpenCV setelah menghapus latar belakang"""
    file_path = remove_background(file_path)
    if not file_path:
        return
    
    parameters = cv2.aruco.DetectorParameters()
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_50)
    detector = HomogeneousBgDetector()
    img = cv2.imread(file_path)
    
    # Deteksi Aruco Marker
    corners, _, _ = cv2.aruco.detectMarkers(img, aruco_dict, parameters=parameters)
    if not corners:
        result_label.config(text='Marker tidak terdeteksi!')
        return
    
    int_corners = np.int0(corners)
    cv2.polylines(img, int_corners, True, (0, 255, 0), 5)
    
    aruco_perimeter = cv2.arcLength(corners[0], True)
    pixel_cm_ratio = aruco_perimeter / 15  # Anggap ukuran marker 15 cm
    
    contours = detector.detect_objects(img)
    
    for cnt in contours:
        rect = cv2.minAreaRect(cnt)
        (x, y), (w, h), angle = rect
        object_width = w / pixel_cm_ratio
        object_height = h / pixel_cm_ratio
        
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        
        cv2.circle(img, (int(x), int(y)), 5, (0, 0, 255), -1)
        cv2.polylines(img, [box], True, (255, 0, 0), 2)
        cv2.putText(img, f"Width {round(object_width, 1)} cm", (int(x - 150), int(y - 70)),
                    cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), 2)
        cv2.putText(img, f"Height {round(object_height, 1)} cm", (int(x - 150), int(y - 100)),
                    cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), 2)
    
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')
    plt.show()

def tampilkan_gambar(file_path):
    """Menampilkan gambar di GUI Tkinter"""
    img = Image.open(file_path)
    img.thumbnail((600, 600), Image.BILINEAR)
    img = ImageTk.PhotoImage(img)
    image_label.config(image=img)
    image_label.image = img

def pilih_file():
    """Memilih file dan memprosesnya (hapus latar belakang lalu deteksi objek)."""
    file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.jpg *.png *.jpeg")])
    if not file_path:
        return
    proses_gambar(file_path)

# GUI Tkinter
window = tk.Tk()
window.title('Background Remover & Object Detector')

process_button = tk.Button(window, text='Proses Gambar (Hapus BG & Deteksi Objek)', command=pilih_file)
process_button.pack(pady=10)

result_label = tk.Label(window, text='')
result_label.pack()

image_label = tk.Label(window)
image_label.pack()

window.mainloop()
